My Project is Online Attendance Management System 

How to run the Onine Attendance Management System Using PHP and MySQL

Extract the file and copy attendance folder
Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
Open PHPMyAdmin (http://localhost/phpmyadmin)
Create a database with name attendance
Import covidtmsdb.sql file(given inside the zip package in SQL file folder)
Run the script http://localhost/attendance

Admin Credential
------------------
Username: admin
Password: password


Teacher Credential
-------------------
Username: jagadeesh@gmail.com
password: password


This is my project 


Thank you.....